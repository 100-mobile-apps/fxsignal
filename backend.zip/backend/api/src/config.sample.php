<?php
// Copy this file to config.php (same folder) and fill in your values.
return [
    'app_name' => 'Forex Signals Live',

    // cPanel → MySQL Databases: create a database + user, add the user to the database (ALL PRIVILEGES)
    'db' => [
        'host' => 'localhost',
        'name' => 'cpaneluser_fxsignals',
        'user' => 'cpaneluser_fxuser',
        'pass' => 'your-database-password',
    ],

    // Long random string (40+ characters). Changing it logs everyone out.
    'jwt_secret' => 'CHANGE_ME_to_a_long_random_string_of_40_plus_characters',

    // Free key from https://twelvedata.com (8 requests/min, 800/day on the free plan)
    'twelvedata_key' => '',
    'requests_per_minute' => 8,

    // Instruments and timeframe the engine watches.
    // Free plan budget: 8 pairs × 3 runs/hour × 24h = 576 requests/day (cron every 20 min).
    'pairs' => ['EUR/USD', 'GBP/USD', 'USD/JPY', 'AUD/USD', 'USD/CAD', 'USD/CHF', 'NZD/USD', 'XAU/USD'],
    'timeframe' => '1h',

    // Signal rules
    'min_confidence' => 65,       // minimum strength (0–100) to publish a signal
    'signal_expiry_hours' => 72,  // open signals are closed at market after this
    'cooldown_hours' => 4,        // wait after a signal closes before a new one on that pair

    // Push notifications (optional). Firebase console → Project settings → Service accounts →
    // Generate new private key. Upload the JSON next to this file.
    'fcm' => [
        'project_id' => '',
        'service_account_file' => __DIR__ . '/firebase-service-account.json',
    ],

    // Public URL of this API (used for unsubscribe links in emails)
    'base_url' => 'https://yourdomain.com/api',

    // Daily/weekly/monthly reports are grouped in this timezone
    'report_timezone' => 'Africa/Lagos',

    // Email: create an account in cPanel → Email Accounts (e.g. alerts@yourdomain.com)
    // and use its SMTP settings (cPanel → Email Accounts → Connect Devices).
    'mail' => [
        'transport' => 'smtp',          // 'smtp' (recommended) or 'mail'
        'host' => 'mail.yourdomain.com',
        'port' => 465,
        'secure' => 'ssl',              // 465 = 'ssl', 587 = 'tls'
        'user' => 'alerts@yourdomain.com',
        'pass' => 'email-account-password',
        'from' => 'alerts@yourdomain.com',
        'from_name' => 'Forex Signals Live',
        'max_per_run' => 40,            // emails per cron run; keep under your host's hourly limit ÷ 3
    ],

    // Developer links shown in the app (WhatsApp chat, Buy Me a Coffee, hire the developer).
    // Set 'coffee' => false if Google Play asks you to remove the tip link; the app picks it up on next launch.
    'promo' => ['coffee' => true, 'whatsapp' => true, 'hire' => true],
    'developer' => [
        'name' => 'Swiftmynd Technologies',
        'whatsapp' => 'https://wa.me/2347011401387?text=Hi%20Abdullahi%2C%20I%20use%20Forex%20Signals%20Live%20and%20I%27d%20like%20to%20talk%20about%20building%20an%20app%20or%20website.',
        'coffee' => 'https://buymeacoffee.com/swalafblogM',
    ],

    'cors_origin' => '*',
    'debug' => false,
];
